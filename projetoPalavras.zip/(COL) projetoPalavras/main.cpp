#include "palavras.h"

int main() 
{

    // inclua aqui o codigo necessario para testar o seu programa,
    // mas lembre-se que apenas o que esta em trabalho.cpp sera
    // avaliado. Cuidado para nao deixar nenhum codigo essencial
    // ao funcionamento do seu EP nesta area!!!

 getch();
}
